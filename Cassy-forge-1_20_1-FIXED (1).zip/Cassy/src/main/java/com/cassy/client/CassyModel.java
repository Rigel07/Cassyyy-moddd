package com.cassy.client;

import com.cassy.entity.CassyEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/** Modelo "chibi" de t-rex: cabezota, cuerpecito, bracitos diminutos y colita. Textura 64x64. */
public class CassyModel extends EntityModel<CassyEntity> {
    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart jaw;
    private final ModelPart tail1;
    private final ModelPart tail2;
    private final ModelPart legR;
    private final ModelPart legL;
    private final ModelPart armR;
    private final ModelPart armL;
    private final ModelPart scarf;

    public CassyModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.jaw = this.head.getChild("jaw");
        this.tail1 = root.getChild("tail1");
        this.tail2 = this.tail1.getChild("tail2");
        this.legR = root.getChild("leg_r");
        this.legL = root.getChild("leg_l");
        this.armR = root.getChild("arm_r");
        this.armL = root.getChild("arm_l");
        this.scarf = root.getChild("scarf");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition p = mesh.getRoot();

        p.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -7.0F, -3.5F, 8.0F, 7.0F, 7.0F),
                PartPose.offset(0.0F, 20.0F, 0.0F));

        PartDefinition headPart = p.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 14).addBox(-5.0F, -8.0F, -8.0F, 10.0F, 8.0F, 9.0F),
                PartPose.offset(0.0F, 15.0F, -3.0F));
        headPart.addOrReplaceChild("jaw",
                CubeListBuilder.create().texOffs(34, 0).addBox(-4.0F, 0.0F, -6.0F, 8.0F, 2.0F, 6.0F),
                PartPose.offset(0.0F, -0.5F, -1.0F));

        PartDefinition tailPart = p.addOrReplaceChild("tail1",
                CubeListBuilder.create().texOffs(40, 9).addBox(-2.5F, -2.5F, 0.0F, 5.0F, 5.0F, 6.0F),
                PartPose.offset(0.0F, 18.0F, 3.0F));
        tailPart.addOrReplaceChild("tail2",
                CubeListBuilder.create().texOffs(40, 21).addBox(-1.5F, -1.5F, 0.0F, 3.0F, 3.0F, 6.0F),
                PartPose.offset(0.0F, 0.0F, 6.0F));

        p.addOrReplaceChild("leg_r",
                CubeListBuilder.create()
                        .texOffs(0, 32).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 4.0F, 3.0F)
                        .texOffs(12, 32).addBox(-1.5F, 3.0F, -3.5F, 3.0F, 1.0F, 2.0F),
                PartPose.offset(-2.5F, 20.0F, 1.0F));
        p.addOrReplaceChild("leg_l",
                CubeListBuilder.create()
                        .texOffs(0, 32).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 4.0F, 3.0F)
                        .texOffs(12, 32).addBox(-1.5F, 3.0F, -3.5F, 3.0F, 1.0F, 2.0F),
                PartPose.offset(2.5F, 20.0F, 1.0F));

        p.addOrReplaceChild("arm_r",
                CubeListBuilder.create().texOffs(24, 32).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F),
                PartPose.offset(-4.5F, 15.0F, -2.0F));
        p.addOrReplaceChild("arm_l",
                CubeListBuilder.create().texOffs(24, 32).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F),
                PartPose.offset(4.5F, 15.0F, -2.0F));

        p.addOrReplaceChild("scarf",
                CubeListBuilder.create().texOffs(0, 40).addBox(-4.5F, -1.5F, -3.5F, 9.0F, 3.0F, 7.0F),
                PartPose.offset(0.0F, 14.0F, -0.5F));

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(CassyEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        boolean sitting = entity.isInSittingPose();
        int action = entity.getAction();
        boolean digging = action == CassyEntity.ACTION_DIG;
        boolean sniffing = action == CassyEntity.ACTION_SNIFF;
        boolean still = sitting || digging || sniffing;

        // Saltito al andar
        float bob = still ? 0.0F : Mth.abs(Mth.sin(limbSwing * 0.6662F)) * limbSwingAmount * 1.3F;

        float bodyY = 20.0F;
        float headY = 15.0F;
        float tailY = 18.0F;
        float legY = 20.0F;
        float armY = 15.0F;
        if (sitting) {
            bodyY = 22.5F;
            headY = 17.5F;
            tailY = 21.5F;
            legY = 22.0F;
            armY = 17.5F;
        }

        body.y = bodyY - bob;
        head.y = headY - bob;
        scarf.y = headY - 1.0F - bob;
        tail1.y = tailY - bob;
        legR.y = legY - bob;
        legL.y = legY - bob;
        armR.y = armY - bob;
        armL.y = armY - bob;

        // Cabeza y mandíbula
        float pitch = headPitch * Mth.DEG_TO_RAD;
        float yaw = netHeadYaw * Mth.DEG_TO_RAD;
        head.yRot = yaw;
        head.xRot = pitch;
        if (digging) {
            head.xRot = pitch + Mth.sin(ageInTicks * 0.9F) * 0.22F;
        } else if (sniffing) {
            head.xRot = pitch + Mth.sin(ageInTicks * 1.1F) * 0.16F;
        }
        scarf.xRot = 0.0F;
        if (entity.isAggressive()) {
            jaw.xRot = 0.35F + Mth.sin(ageInTicks * 0.8F) * 0.3F;
        } else if (sniffing || digging) {
            jaw.xRot = 0.1F;
        } else {
            jaw.xRot = 0.03F + Mth.sin(ageInTicks * 0.1F) * 0.02F;
        }

        // Patitas
        float swing = Mth.cos(limbSwing * 0.6662F) * 1.3F * limbSwingAmount;
        if (sitting) {
            legR.xRot = -1.45F;
            legL.xRot = -1.45F;
            legR.zRot = 0.18F;
            legL.zRot = -0.18F;
        } else {
            legR.xRot = swing;
            legL.xRot = -swing;
            legR.zRot = 0.0F;
            legL.zRot = 0.0F;
        }

        // Bracitos diminutos
        armR.zRot = 0.2F;
        armL.zRot = -0.2F;
        if (digging) {
            armR.xRot = -1.0F + Mth.sin(ageInTicks * 1.4F) * 0.9F;
            armL.xRot = -1.0F + Mth.sin(ageInTicks * 1.4F + Mth.PI) * 0.9F;
        } else if (sitting) {
            armR.xRot = -0.5F;
            armL.xRot = -0.5F;
        } else {
            armR.xRot = -0.7F - swing * 0.4F + Mth.sin(ageInTicks * 0.1F) * 0.05F;
            armL.xRot = -0.7F + swing * 0.4F - Mth.sin(ageInTicks * 0.1F) * 0.05F;
        }

        // Colita: se mece, y mueve más cuando está emocionada
        float wag = (digging || sniffing) ? 0.4F : 0.12F;
        tail1.xRot = sitting ? 0.05F : 0.2F + limbSwingAmount * 0.15F;
        tail1.yRot = Mth.cos(ageInTicks * (digging || sniffing ? 0.5F : 0.12F)) * wag
                + Mth.cos(limbSwing * 0.6662F) * 0.35F * limbSwingAmount;
        tail2.xRot = sitting ? 0.0F : -0.1F;
        tail2.yRot = Mth.cos(ageInTicks * (digging || sniffing ? 0.5F : 0.12F) - 0.8F) * wag * 1.4F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
