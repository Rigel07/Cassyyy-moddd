package com.cassy.client;

import com.cassy.CassyMod;
import com.cassy.entity.CassyEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class CassyRenderer extends MobRenderer<CassyEntity, CassyModel> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(CassyMod.MOD_ID, "cassy"), "main");

    private static final ResourceLocation TEXTURE_WILD =
            new ResourceLocation(CassyMod.MOD_ID, "textures/entity/cassy.png");
    /** La domesticada lleva una bufandita roja. */
    private static final ResourceLocation TEXTURE_TAME =
            new ResourceLocation(CassyMod.MOD_ID, "textures/entity/cassy_tame.png");

    public CassyRenderer(EntityRendererProvider.Context context) {
        super(context, new CassyModel(context.bakeLayer(LAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(CassyEntity entity) {
        return entity.isTame() ? TEXTURE_TAME : TEXTURE_WILD;
    }

    @Override
    protected void scale(CassyEntity entity, PoseStack poseStack, float partialTick) {
        if (entity.isBaby()) {
            poseStack.scale(0.55F, 0.55F, 0.55F);
        }
    }
}
