package com.cassy;

import com.cassy.entity.CassyEntity;
import com.cassy.item.AmberItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModRegistry {
    private ModRegistry() {}

    private static final String ID = CassyMod.MOD_ID;

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ID);
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ID);

    /** Carnes con las que se doma, se cura y se cría a Cassy (ver data/cassy/tags/items/meat.json). */
    public static final TagKey<Item> MEAT = ItemTags.create(new ResourceLocation(ID, "meat"));

    // ---- Sonidos (se mapean en assets/cassy/sounds.json a sonidos de vanilla) ----
    public static final RegistryObject<SoundEvent> SOUND_AMBIENT = sound("entity.cassy.ambient");
    public static final RegistryObject<SoundEvent> SOUND_HURT = sound("entity.cassy.hurt");
    public static final RegistryObject<SoundEvent> SOUND_DEATH = sound("entity.cassy.death");
    public static final RegistryObject<SoundEvent> SOUND_HAPPY = sound("entity.cassy.happy");
    public static final RegistryObject<SoundEvent> SOUND_ROAR = sound("entity.cassy.roar");
    public static final RegistryObject<SoundEvent> SOUND_SNIFF = sound("entity.cassy.sniff");
    public static final RegistryObject<SoundEvent> SOUND_DIG = sound("entity.cassy.dig");

    // ---- Bloques ----
    public static final RegistryObject<Block> FOSSIL_ROCK = BLOCKS.register("fossil_rock",
            () -> new DropExperienceBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.STONE)
                    .strength(3.0F, 3.0F)
                    .requiresCorrectToolForDrops()
                    .sound(SoundType.STONE), UniformInt.of(0, 2)));

    public static final RegistryObject<Block> DEEPSLATE_FOSSIL_ROCK = BLOCKS.register("deepslate_fossil_rock",
            () -> new DropExperienceBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.DEEPSLATE)
                    .strength(4.5F, 3.0F)
                    .requiresCorrectToolForDrops()
                    .sound(SoundType.DEEPSLATE), UniformInt.of(0, 2)));

    public static final RegistryObject<Block> FOSSIL_DIRT = BLOCKS.register("fossil_dirt",
            () -> new DropExperienceBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.DIRT)
                    .strength(0.8F)
                    .sound(SoundType.GRAVEL), UniformInt.of(0, 1)));

    public static final RegistryObject<Block> FOSSIL_BRICKS = BLOCKS.register("fossil_bricks",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.SAND)
                    .strength(2.0F, 6.0F)
                    .requiresCorrectToolForDrops()
                    .sound(SoundType.STONE)));

    // ---- Entidad ----
    public static final RegistryObject<EntityType<CassyEntity>> CASSY = ENTITIES.register("cassy",
            () -> EntityType.Builder.<CassyEntity>of(CassyEntity::new, MobCategory.CREATURE)
                    .sized(0.8F, 1.0F)
                    .clientTrackingRange(8)
                    .build(ID + ":cassy"));

    // ---- Objetos ----
    public static final RegistryObject<Item> FOSSIL_FRAGMENT = ITEMS.register("fossil_fragment",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> DINO_BONE = ITEMS.register("dino_bone",
            () -> new Item(new Item.Properties().rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> AMBER = ITEMS.register("amber",
            () -> new AmberItem(new Item.Properties().rarity(Rarity.RARE).stacksTo(16)));

    public static final RegistryObject<Item> FOSSIL_ROCK_ITEM = ITEMS.register("fossil_rock",
            () -> new BlockItem(FOSSIL_ROCK.get(), new Item.Properties()));
    public static final RegistryObject<Item> DEEPSLATE_FOSSIL_ROCK_ITEM = ITEMS.register("deepslate_fossil_rock",
            () -> new BlockItem(DEEPSLATE_FOSSIL_ROCK.get(), new Item.Properties()));
    public static final RegistryObject<Item> FOSSIL_DIRT_ITEM = ITEMS.register("fossil_dirt",
            () -> new BlockItem(FOSSIL_DIRT.get(), new Item.Properties()));
    public static final RegistryObject<Item> FOSSIL_BRICKS_ITEM = ITEMS.register("fossil_bricks",
            () -> new BlockItem(FOSSIL_BRICKS.get(), new Item.Properties()));

    public static final RegistryObject<Item> SPAWN_EGG = ITEMS.register("cassy_spawn_egg",
            () -> new ForgeSpawnEggItem(CASSY, 0x8A5A38, 0xF3DDB0, new Item.Properties()));

    // ---- Pestaña creativa ----
    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("cassy_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.cassy"))
                    .icon(() -> new ItemStack(DINO_BONE.get()))
                    .displayItems((params, output) -> {
                        output.accept(SPAWN_EGG.get());
                        output.accept(FOSSIL_FRAGMENT.get());
                        output.accept(DINO_BONE.get());
                        output.accept(AMBER.get());
                        output.accept(FOSSIL_DIRT_ITEM.get());
                        output.accept(FOSSIL_ROCK_ITEM.get());
                        output.accept(DEEPSLATE_FOSSIL_ROCK_ITEM.get());
                        output.accept(FOSSIL_BRICKS_ITEM.get());
                    })
                    .build());

    private static RegistryObject<SoundEvent> sound(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(ID, name)));
    }

    public static void register(IEventBus bus) {
        SOUNDS.register(bus);
        BLOCKS.register(bus);
        ITEMS.register(bus);
        ENTITIES.register(bus);
        TABS.register(bus);
    }
}
