package com.cassy.entity;

import com.cassy.ModRegistry;
import com.cassy.entity.goal.FindFossilGoal;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.BreedGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.TemptGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Ghast;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Cassy: un pequeño t-rex marrón, achuchable y muy buen olfato para los fósiles. */
public class CassyEntity extends TamableAnimal {
    public static final int ACTION_NONE = 0;
    public static final int ACTION_DIG = 1;
    public static final int ACTION_SNIFF = 2;

    /** 1 de cada N trozos de carne consigue domesticarla. */
    private static final int TAME_CHANCE = 3;

    private static final EntityDataAccessor<Integer> DATA_ACTION =
            SynchedEntityData.defineId(CassyEntity.class, EntityDataSerializers.INT);

    /** Ticks hasta que pueda volver a buscar fósiles. */
    private int findCooldown = 400;
    /** Ticks hasta el próximo abrazo con efecto. */
    private int hugCooldown = 0;
    /** Sitios que ya te ha señalado (no se guarda en disco). */
    private final Set<Long> hinted = new HashSet<>();

    public CassyEntity(EntityType<? extends CassyEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.ATTACK_DAMAGE, 3.0D);
    }

    // ------------------------------------------------------------------ IA

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new SitWhenOrderedToGoal(this));
        this.goalSelector.addGoal(2, new PanicGoal(this, 1.5D) {
            @Override
            public boolean canUse() {
                return !CassyEntity.this.isTame() && super.canUse();
            }
        });
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2D, true));
        this.goalSelector.addGoal(3, new FindFossilGoal(this));
        this.goalSelector.addGoal(4, new FollowOwnerGoal(this, 1.15D, 6.0F, 2.0F, false));
        this.goalSelector.addGoal(6, new BreedGoal(this, 1.0D));
        this.goalSelector.addGoal(7, new TemptGoal(this, 1.1D, Ingredient.of(ModRegistry.MEAT), false));
        this.goalSelector.addGoal(8, new WaterAvoidingRandomStrollGoal(this, 1.0D));
        this.goalSelector.addGoal(9, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(10, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
    }

    @Override
    public boolean wantsToAttack(LivingEntity target, LivingEntity owner) {
        if (target instanceof Creeper || target instanceof Ghast || target instanceof ArmorStand) {
            return false;
        }
        if (target instanceof TamableAnimal pet && pet.isTame() && pet.getOwner() == owner) {
            return false;
        }
        if (target instanceof Player victim && owner instanceof Player attacker && !attacker.canHarmPlayer(victim)) {
            return false;
        }
        return super.wantsToAttack(target, owner);
    }

    // ------------------------------------------------------------- Datos

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_ACTION, ACTION_NONE);
    }

    public int getAction() {
        return this.entityData.get(DATA_ACTION);
    }

    public void setAction(int action) {
        this.entityData.set(DATA_ACTION, action);
    }

    /** Tono de voz (para poder usarlo desde las metas de IA). */
    public float voicePitch() {
        return getVoicePitch();
    }

    public int getFindCooldown() {
        return findCooldown;
    }

    public void setFindCooldown(int ticks) {
        this.findCooldown = ticks;
    }

    public boolean hasHinted(BlockPos pos) {
        return hinted.contains(pos.asLong());
    }

    public void addHinted(BlockPos pos) {
        if (hinted.size() > 64) {
            hinted.clear();
        }
        hinted.add(pos.asLong());
    }

    // ------------------------------------------------------ Comida / carne

    /** Cualquier carne (menos la podrida): la de vanilla, la de otros mods marcada como carne y el tag cassy:meat. */
    public static boolean isMeat(ItemStack stack) {
        if (stack.is(ModRegistry.MEAT)) {
            return true;
        }
        Item item = stack.getItem();
        if (item == Items.ROTTEN_FLESH || !item.isEdible()) {
            return false;
        }
        FoodProperties food = item.getFoodProperties();
        return food != null && food.isMeat();
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return isMeat(stack);
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob other) {
        CassyEntity baby = ModRegistry.CASSY.get().create(level);
        if (baby != null && isTame()) {
            UUID owner = getOwnerUUID();
            if (owner != null) {
                baby.setOwnerUUID(owner);
                baby.setTame(true);
            }
        }
        return baby;
    }

    // ------------------------------------------------------ Interacción

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        // Salvaje: la carne puede domesticarla.
        if (!isTame()) {
            if (isMeat(stack)) {
                if (!level().isClientSide) {
                    if (!player.getAbilities().instabuild) {
                        stack.shrink(1);
                    }
                    if (this.random.nextInt(TAME_CHANCE) == 0) {
                        tame(player);
                        this.navigation.stop();
                        setTarget(null);
                        setOrderedToSit(false);
                        setInSittingPose(false);
                        getAttribute(Attributes.MAX_HEALTH).setBaseValue(30.0D);
                        setHealth(30.0F);
                        findCooldown = 200;
                        level().broadcastEntityEvent(this, (byte) 7);
                        playSound(ModRegistry.SOUND_HAPPY.get(), 1.0F, getVoicePitch());
                    } else {
                        level().broadcastEntityEvent(this, (byte) 6);
                        playSound(ModRegistry.SOUND_SNIFF.get(), 1.0F, getVoicePitch());
                    }
                }
                return InteractionResult.sidedSuccess(level().isClientSide);
            }
            return InteractionResult.PASS;
        }

        if (!isOwnedBy(player)) {
            return InteractionResult.PASS;
        }

        // Hueso de dinosaurio: se pone fuerte y veloz.
        if (stack.is(ModRegistry.DINO_BONE.get())) {
            if (!level().isClientSide) {
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                heal(getMaxHealth());
                addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 1200, 1));
                addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 1200, 0));
                playSound(ModRegistry.SOUND_ROAR.get(), 1.0F, 1.7F);
                level().broadcastEntityEvent(this, (byte) 7);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }

        // Carne con la vida baja: la cura. Con la vida llena, sirve para criar.
        if (isMeat(stack) && getHealth() < getMaxHealth()) {
            if (!level().isClientSide) {
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                heal(4.0F);
                level().broadcastEntityEvent(this, (byte) 7);
                playSound(ModRegistry.SOUND_HAPPY.get(), 1.0F, getVoicePitch());
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }

        // Agachado + mano vacía: abrazo.
        if (stack.isEmpty() && player.isShiftKeyDown()) {
            if (!level().isClientSide) {
                hug(player);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }

        // Crianza y crecimiento de los bebés (carne con la vida llena).
        InteractionResult result = super.mobInteract(player, hand);
        if (result.consumesAction()) {
            return result;
        }

        // Mano vacía: alterna "quieta" / "sígueme".
        if (stack.isEmpty()) {
            if (!level().isClientSide) {
                boolean sit = !isOrderedToSit();
                setOrderedToSit(sit);
                this.jumping = false;
                this.navigation.stop();
                setTarget(null);
                player.displayClientMessage(
                        Component.translatable(sit ? "message.cassy.stay" : "message.cassy.follow"), true);
                playSound(ModRegistry.SOUND_HAPPY.get(), 1.0F, getVoicePitch());
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return InteractionResult.PASS;
    }

    private void hug(Player player) {
        if (hugCooldown > 0) {
            if (level() instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.HEART, getX(), getY() + 1.0D, getZ(), 2, 0.3D, 0.3D, 0.3D, 0.01D);
            }
            playSound(ModRegistry.SOUND_HAPPY.get(), 0.6F, getVoicePitch());
            return;
        }
        hugCooldown = 1200;
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0));
        playSound(ModRegistry.SOUND_HAPPY.get(), 1.0F, getVoicePitch());
        if (level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.HEART, getX(), getY() + 1.0D, getZ(), 8, 0.4D, 0.4D, 0.4D, 0.02D);
        }
        player.displayClientMessage(Component.translatable("message.cassy.hug"), true);
    }

    // ------------------------------------------------------------ Spawn

    /** Aparecen en llanuras, sabana, bosque y selva: sobre hierba, arena, tierra o arcilla. */
    public static boolean checkCassySpawnRules(EntityType<CassyEntity> type, LevelAccessor level,
                                               MobSpawnType reason, BlockPos pos, RandomSource random) {
        BlockState below = level.getBlockState(pos.below());
        boolean ground = below.is(BlockTags.ANIMALS_SPAWNABLE_ON) || below.is(BlockTags.SAND)
                || below.is(BlockTags.TERRACOTTA) || below.is(BlockTags.DIRT);
        return ground && level.getRawBrightness(pos, 0) > 8;
    }

    // ------------------------------------------------------------- Tick

    @Override
    public void aiStep() {
        super.aiStep();
        if (!level().isClientSide) {
            if (findCooldown > 0) {
                findCooldown--;
            }
            if (hugCooldown > 0) {
                hugCooldown--;
            }
        }
    }

    @Override
    protected float getStandingEyeHeight(Pose pose, EntityDimensions dimensions) {
        return dimensions.height * 0.8F;
    }

    // ----------------------------------------------------------- Sonidos

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return getAction() == ACTION_NONE ? ModRegistry.SOUND_AMBIENT.get() : null;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModRegistry.SOUND_HURT.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModRegistry.SOUND_DEATH.get();
    }
}
