package com.cassy.entity.goal;

import com.cassy.ModRegistry;
import com.cassy.entity.CassyEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;

/**
 * Cassy huele fósiles cerca de su dueño:
 * <ul>
 *   <li>DIG: un fósil al que puede llegar -> va, lo desentierra y te deja el botín.</li>
 *   <li>MARK: arena/grava sospechosa (arqueología) a su alcance -> va y te la señala.</li>
 *   <li>SNIFF: un fósil enterrado sin camino -> olfatea y te dice en qué dirección está.</li>
 * </ul>
 */
public class FindFossilGoal extends Goal {
    private enum Mode { DIG, MARK, SNIFF }

    private static final int RADIUS = 14;
    private static final int REACH_VERTICAL = 8;
    private static final int SNIFF_VERTICAL = 10;
    private static final int DIG_TICKS = 70;
    private static final int MARK_TICKS = 80;
    private static final int SNIFF_TICKS = 70;

    private final CassyEntity cassy;
    private Mode mode;
    private BlockPos target;
    private BlockPos stand;
    private boolean arrived;
    private boolean done;
    private int phaseTicks;
    private int walkTicks;
    private int scanDelay = 20;

    public FindFossilGoal(CassyEntity cassy) {
        this.cassy = cassy;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    // ------------------------------------------------------------- Reglas

    @Override
    public boolean canUse() {
        if (!cassy.isTame() || cassy.isBaby() || cassy.isOrderedToSit() || cassy.isInSittingPose()
                || cassy.getFindCooldown() > 0 || cassy.getTarget() != null) {
            return false;
        }
        LivingEntity owner = cassy.getOwner();
        if (owner == null || !owner.isAlive() || cassy.distanceToSqr(owner) > 20.0D * 20.0D) {
            return false;
        }
        if (--scanDelay > 0) {
            return false;
        }
        scanDelay = 30 + cassy.getRandom().nextInt(30);
        return scan();
    }

    @Override
    public boolean canContinueToUse() {
        if (done || target == null || !cassy.isTame() || cassy.isOrderedToSit() || cassy.getTarget() != null
                || walkTicks > 300) {
            return false;
        }
        LivingEntity owner = cassy.getOwner();
        if (owner == null || !owner.isAlive() || cassy.distanceToSqr(owner) > 26.0D * 26.0D) {
            return false;
        }
        BlockState state = cassy.level().getBlockState(target);
        return mode == Mode.MARK ? isSuspicious(state) : isFossil(state);
    }

    @Override
    public void start() {
        done = false;
        phaseTicks = 0;
        walkTicks = 0;
        arrived = stand == null;
        if (stand != null) {
            cassy.getNavigation().moveTo(stand.getX() + 0.5D, stand.getY(), stand.getZ() + 0.5D, 1.2D);
        } else {
            cassy.getNavigation().stop();
            beginAction();
        }
        cassy.playSound(ModRegistry.SOUND_SNIFF.get(), 1.0F, cassy.voicePitch());
    }

    @Override
    public void stop() {
        cassy.setAction(CassyEntity.ACTION_NONE);
        cassy.getNavigation().stop();
        cassy.setFindCooldown(Math.max(cassy.getFindCooldown(), 200));
        target = null;
        stand = null;
        mode = null;
    }

    // --------------------------------------------------------------- Tick

    @Override
    public void tick() {
        if (target == null) {
            return;
        }
        Vec3 look = Vec3.atCenterOf(target);
        cassy.getLookControl().setLookAt(look.x, look.y, look.z, 30.0F, 30.0F);

        if (!arrived) {
            walkTicks++;
            double distSqr = cassy.distanceToSqr(stand.getX() + 0.5D, stand.getY(), stand.getZ() + 0.5D);
            if (distSqr <= 2.5D) {
                arrived = true;
                cassy.getNavigation().stop();
                beginAction();
            } else if (cassy.getNavigation().isDone()) {
                if (walkTicks > 20) {
                    walkTicks = 999; // no llega: se rinde
                } else {
                    cassy.getNavigation().moveTo(stand.getX() + 0.5D, stand.getY(), stand.getZ() + 0.5D, 1.2D);
                }
            }
            return;
        }

        phaseTicks++;
        if (!(cassy.level() instanceof ServerLevel level)) {
            return;
        }
        switch (mode) {
            case DIG -> tickDig(level);
            case MARK -> tickMark(level);
            case SNIFF -> tickSniff(level);
        }
    }

    private void beginAction() {
        cassy.setAction(mode == Mode.DIG ? CassyEntity.ACTION_DIG : CassyEntity.ACTION_SNIFF);
        phaseTicks = 0;
    }

    private void tickDig(ServerLevel level) {
        if (phaseTicks % 7 == 0) {
            BlockState state = level.getBlockState(target);
            Vec3 c = Vec3.atCenterOf(target);
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, state), c.x, c.y, c.z,
                    8, 0.3D, 0.3D, 0.3D, 0.05D);
            cassy.playSound(ModRegistry.SOUND_DIG.get(), 0.9F, 0.9F + cassy.getRandom().nextFloat() * 0.3F);
        }
        if (phaseTicks >= DIG_TICKS) {
            finishDig(level);
        }
    }

    private void finishDig(ServerLevel level) {
        BlockState state = level.getBlockState(target);
        if (isFossil(state)) {
            Block.dropResources(state, level, target);
            state.spawnAfterBreak(level, target, ItemStack.EMPTY, true);
            level.destroyBlock(target, false);
            if (cassy.getRandom().nextInt(2) == 0) {
                Block.popResource(level, target, new ItemStack(ModRegistry.FOSSIL_FRAGMENT.get()));
            }
            level.sendParticles(ParticleTypes.HEART, cassy.getX(), cassy.getY() + 1.0D, cassy.getZ(),
                    6, 0.4D, 0.4D, 0.4D, 0.02D);
            cassy.playSound(ModRegistry.SOUND_ROAR.get(), 0.9F, 1.8F);
            tell(Component.translatable("message.cassy.dug"));
        }
        cassy.addHinted(target);
        cassy.setFindCooldown(900 + cassy.getRandom().nextInt(600));
        done = true;
    }

    private void tickMark(ServerLevel level) {
        if (phaseTicks % 15 == 0) {
            cassy.playSound(ModRegistry.SOUND_SNIFF.get(), 0.9F, cassy.voicePitch());
        }
        if (phaseTicks % 8 == 0) {
            Vec3 c = Vec3.atCenterOf(target);
            level.sendParticles(ParticleTypes.HAPPY_VILLAGER, c.x, c.y + 0.7D, c.z, 4, 0.3D, 0.2D, 0.3D, 0.0D);
        }
        if (phaseTicks >= MARK_TICKS) {
            cassy.playSound(ModRegistry.SOUND_ROAR.get(), 0.8F, 1.9F);
            tell(Component.translatable("message.cassy.found_buried"));
            cassy.addHinted(target);
            cassy.setFindCooldown(700 + cassy.getRandom().nextInt(400));
            done = true;
        }
    }

    private void tickSniff(ServerLevel level) {
        if (phaseTicks % 14 == 0) {
            cassy.playSound(ModRegistry.SOUND_SNIFF.get(), 0.9F, cassy.voicePitch());
        }
        if (phaseTicks >= SNIFF_TICKS) {
            int dx = target.getX() - cassy.getBlockX();
            int dz = target.getZ() - cassy.getBlockZ();
            int dy = target.getY() - cassy.getBlockY();
            Direction dir = Direction.getNearest(dx, 0.0D, dz);
            int horizontal = (int) Math.round(Math.sqrt((double) dx * dx + (double) dz * dz));
            Component vertical = Component.translatable(
                    dy < -1 ? "message.cassy.below" : dy > 1 ? "message.cassy.above" : "message.cassy.level",
                    Math.abs(dy));
            tell(Component.translatable("message.cassy.sniff",
                    Component.translatable("message.cassy.dir." + dir.getName()), horizontal, vertical));
            level.sendParticles(ParticleTypes.NOTE, cassy.getX(), cassy.getY() + 1.2D, cassy.getZ(),
                    2, 0.3D, 0.2D, 0.3D, 0.0D);
            cassy.playSound(ModRegistry.SOUND_ROAR.get(), 0.7F, 2.0F);
            cassy.addHinted(target);
            cassy.setFindCooldown(1200 + cassy.getRandom().nextInt(600));
            done = true;
        }
    }

    private void tell(Component message) {
        LivingEntity owner = cassy.getOwner();
        if (owner instanceof Player player) {
            player.displayClientMessage(message, true);
        }
    }

    // ----------------------------------------------------------- Búsqueda

    private boolean scan() {
        Level level = cassy.level();
        BlockPos origin = cassy.blockPosition();
        List<BlockPos> fossils = new ArrayList<>();
        List<BlockPos> marks = new ArrayList<>();

        for (BlockPos p : BlockPos.betweenClosed(origin.offset(-RADIUS, -SNIFF_VERTICAL, -RADIUS),
                origin.offset(RADIUS, SNIFF_VERTICAL, RADIUS))) {
            if (!level.hasChunkAt(p)) {
                continue;
            }
            BlockState state = level.getBlockState(p);
            if (state.isAir()) {
                continue;
            }
            if (isFossil(state)) {
                fossils.add(p.immutable());
            } else if (isSuspicious(state) && Math.abs(p.getY() - origin.getY()) <= REACH_VERTICAL) {
                marks.add(p.immutable());
            }
        }
        if (fossils.isEmpty() && marks.isEmpty()) {
            return false;
        }

        Comparator<BlockPos> byDistance = Comparator.comparingDouble(p -> p.distSqr(origin));
        fossils.sort(byDistance);
        marks.sort(byDistance);

        // 1) Fósil al alcance: lo desentierra.
        int tried = 0;
        for (BlockPos f : fossils) {
            if (tried++ >= 3) {
                break;
            }
            BlockPos s = findStandPos(level, f);
            if (s != null) {
                setPlan(Mode.DIG, f, s);
                return true;
            }
        }
        // 2) Arena/grava sospechosa al alcance: la señala.
        tried = 0;
        for (BlockPos m : marks) {
            if (cassy.hasHinted(m)) {
                continue;
            }
            if (tried++ >= 3) {
                break;
            }
            BlockPos s = findStandPos(level, m);
            if (s != null) {
                setPlan(Mode.MARK, m, s);
                return true;
            }
        }
        // 3) Fósil enterrado: olfatea y avisa de la dirección.
        for (BlockPos f : fossils) {
            if (!cassy.hasHinted(f)) {
                setPlan(Mode.SNIFF, f, null);
                return true;
            }
        }
        return false;
    }

    private void setPlan(Mode mode, BlockPos target, BlockPos stand) {
        this.mode = mode;
        this.target = target;
        this.stand = stand;
    }

    /** Un sitio pegado al bloque donde Cassy cabe y al que de verdad puede llegar andando. */
    private BlockPos findStandPos(Level level, BlockPos block) {
        Direction[] dirs = {Direction.UP, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
        for (Direction dir : dirs) {
            BlockPos c = block.relative(dir);
            BlockState feet = level.getBlockState(c);
            if (!feet.getCollisionShape(level, c).isEmpty() || !feet.getFluidState().isEmpty()) {
                continue;
            }
            Path path = cassy.getNavigation().createPath(c, 0);
            if (path != null && path.canReach()) {
                return c;
            }
        }
        return null;
    }

    private static boolean isFossil(BlockState state) {
        return state.is(ModRegistry.FOSSIL_ROCK.get())
                || state.is(ModRegistry.DEEPSLATE_FOSSIL_ROCK.get())
                || state.is(ModRegistry.FOSSIL_DIRT.get());
    }

    private static boolean isSuspicious(BlockState state) {
        return state.is(Blocks.SUSPICIOUS_SAND) || state.is(Blocks.SUSPICIOUS_GRAVEL);
    }
}
