# Cassy (mod para Minecraft Forge 1.20.1)

Cassy es un pequeño t-rex marrón, achuchable y adorable, con un olfato increíble para los fósiles.

## Cómo conseguir el .jar con GitHub
1. Crea un repositorio nuevo en GitHub.
2. Sube **todo el contenido** de esta carpeta (incluida la carpeta oculta `.github`).
   Si la subida web no incluye `.github`, crea el archivo a mano con
   *Add file > Create new file* y el nombre `.github/workflows/build.yml`.
3. Ve a la pestaña **Actions**. Se ejecutará solo "Compilar mod (.jar)" (tarda unos minutos).
4. Cuando termine en verde, entra en la ejecución y descarga el artefacto **Cassy-jar**.
   Dentro está `cassy-1.0.0.jar`: cópialo a la carpeta `mods` de Forge 1.20.1 (Forge 47.3.0 o superior).
   Ese mismo .jar es el que se sube a CurseForge.

## Cómo se juega
- **Dónde vive**: llanuras, sabana, bosque, selva y mesetas (en grupos de 1 a 3).
- **Domesticar**: dale carne (cruda o cocinada; la podrida no vale). 1 de cada 3 intentos funciona.
  Al domesticarla le sale una bufandita roja y sube a 30 de vida.
- **Quieta / sígueme**: clic derecho con la mano vacía.
- **Abrazo**: agáchate y clic derecho con la mano vacía. Te da regeneración unos segundos (1 minuto de espera).
- **Curar**: carne con la vida baja. **Criar**: carne con la vida llena a dos Cassys domesticadas (la cría nace tuya).
- **Defensa**: ataca a lo que te ataque o a lo que tú ataques (nunca a creepers, ghasts ni a otras mascotas tuyas).
- **Hueso de dinosaurio** (dárselo): la cura del todo y la pone fuerte y veloz 1 minuto.

## Fósiles
Cassy huele fósiles en un radio de unos 14 bloques mientras estás cerca (y no esté sentada):
- **Fósil que puede alcanzar** -> va, cava con sus bracitos y lo desentierra. Te deja el botín y se pone contenta.
- **Arena o grava sospechosa** (arqueología) -> va y te la señala con partículas. Úsala con un cepillo.
- **Fósil enterrado sin camino** -> olfatea y te dice en el mensaje de la barra en qué dirección y a cuántos bloques está.
Después descansa unos 45-75 segundos antes de volver a buscar.

Bloques (en la pestaña creativa "Cassy"):
- **Tierra fosilífera**: aparece en la superficie de llanuras, bosques, sabana y selva. La que Cassy desentierra más a menudo. Se cava con pala.
- **Roca fosilífera** / **Pizarra abisal fosilífera**: vetas bajo tierra (con pico). Con toque de seda se obtienen enteras.
- **Ladrillos de fósil**: decoración (2x2 fragmentos = 4 ladrillos).

Objetos:
- **Fragmento de fósil**: material común.
- **Hueso de dinosaurio** (15 %): el premio de Cassy. En el crafteo da **9 de polvo de hueso**.
- **Ámbar prehistórico** (4 %): al usarlo da **suerte** durante 5 minutos.
Fortuna aumenta los fragmentos. Cassy a veces suelta un fragmento extra.

## Ajustes rápidos
- `CassyEntity.java`: `TAME_CHANCE` (dificultad de domesticar).
- `FindFossilGoal.java`: `RADIUS` (radio de búsqueda) y los tiempos `DIG_TICKS`, `MARK_TICKS`, `SNIFF_TICKS`.
- `data/cassy/worldgen/placed_feature/`: cuántos fósiles se generan.
- `data/cassy/tags/items/meat.json`: qué cuenta como carne (también acepta la carne marcada como tal en otros mods).
